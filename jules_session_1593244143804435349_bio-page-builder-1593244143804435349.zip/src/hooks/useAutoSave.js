import { useEffect, useRef } from 'react';
import { useBioStore } from './useBioStore.jsx';

export function useAutoSave() {
  const { state, dispatch } = useBioStore();
  const lastSavedState = useRef(JSON.stringify({ profile: state.profile, links: state.links, templateId: state.templateId }));

  useEffect(() => {
    if (!state.settings.autoSave) return;

    const interval = setInterval(() => {
      const currentState = JSON.stringify({ profile: state.profile, links: state.links, templateId: state.templateId });
      
      if (currentState !== lastSavedState.current) {
        // We don't want to flood the history with auto-saves.
        // Instead, we can just log that it's "ready for save" or just let the localStorage sync in App.jsx handle the persistence.
        // The user's named snapshots should remain clean.
        console.log('State changed - ready for manual save or auto-persisted via localStorage sync');
        lastSavedState.current = currentState;
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [state.profile, state.links, state.templateId, state.settings.autoSave]);
}
