import React, { createContext, useContext, useReducer, useEffect } from 'react';

const BioContext = createContext();

const initialState = {
  profile: {
    name: 'Jane Doe',
    bio: 'Digital Creator & Designer',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jane',
    accentColor: '#3b82f6',
    fontFamily: 'sans',
    buttonStyle: 'rounded-xl',
  },
  links: [
    { id: '1', label: 'Instagram', url: 'https://instagram.com', icon: 'Instagram' },
    { id: '2', label: 'Twitter', url: 'https://twitter.com', icon: 'Twitter' },
    { id: '3', label: 'My Website', url: 'https://example.com', icon: 'Globe' },
  ],
  templateId: 'minimal',
  history: [],
  settings: {
    geminiApiKey: '',
    autoSave: true,
    theme: 'light',
  },
};

function bioReducer(state, action) {
  switch (action.type) {
    case 'UPDATE_PROFILE':
      return { ...state, profile: { ...state.profile, ...action.payload } };
    case 'ADD_LINK':
      return { ...state, links: [...state.links, action.payload] };
    case 'UPDATE_LINK':
      return {
        ...state,
        links: state.links.map((l) => (l.id === action.payload.id ? action.payload : l)),
      };
    case 'DELETE_LINK':
      return { ...state, links: state.links.filter((l) => l.id !== action.payload) };
    case 'SET_LINKS':
      return { ...state, links: action.payload };
    case 'SET_TEMPLATE':
      return { ...state, templateId: action.payload };
    case 'SAVE_SNAPSHOT':
      return {
        ...state,
        history: [
          {
            id: Date.now().toString(),
            name: action.payload.name,
            date: new Date().toISOString(),
            data: { profile: state.profile, links: state.links, templateId: state.templateId },
          },
          ...state.history,
        ],
      };
    case 'LOAD_SNAPSHOT':
      return {
        ...state,
        profile: action.payload.profile,
        links: action.payload.links,
        templateId: action.payload.templateId,
      };
    case 'DELETE_SNAPSHOT':
      return { ...state, history: state.history.filter((h) => h.id !== action.payload) };
    case 'UPDATE_SETTINGS':
      return { ...state, settings: { ...state.settings, ...action.payload } };
    case 'HYDRATE':
      return { ...state, ...action.payload };
    default:
      return state;
  }
}

export function BioProvider({ children }) {
  const [state, dispatch] = useReducer(bioReducer, initialState);

  // Persistence logic will be handled by App or separate hook
  
  return (
    <BioContext.Provider value={{ state, dispatch }}>
      {children}
    </BioContext.Provider>
  );
}

export function useBioStore() {
  const context = useContext(BioContext);
  if (!context) {
    throw new Error('useBioStore must be used within a BioProvider');
  }
  return context;
}
