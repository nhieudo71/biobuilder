import { useState } from 'react';

export function useGemini() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const generateContent = async (apiKey, prompt) => {
    if (!apiKey) {
      setError('Gemini API Key is missing. Please add it in settings.');
      return null;
    }

    setLoading(true);
    setError(null);
    try {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { temperature: 0.8, maxOutputTokens: 500 }
          })
        }
      );
      
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error?.message || 'Failed to generate content');
      }

      const data = await res.json();
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
      setLoading(false);
      return text;
    } catch (err) {
      setError(err.message);
      setLoading(false);
      return null;
    }
  };

  return { generateContent, loading, error };
}
