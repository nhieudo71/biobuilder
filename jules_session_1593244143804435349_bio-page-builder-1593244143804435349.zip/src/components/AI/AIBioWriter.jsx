import React, { useState } from 'react';
import { useBioStore } from '../../hooks/useBioStore.jsx';
import { useGemini } from '../../hooks/useGemini';
import { Button } from '../Shared/Button';
import { Sparkles, Loader2 } from 'lucide-react';
import { BioSkeleton } from '../Shared/Skeleton';

export function AIBioWriter() {
  const { state, dispatch } = useBioStore();
  const { generateContent, loading } = useGemini();
  const [prompt, setPrompt] = useState('');

  const handleGenerate = async () => {
    const apiKey = state.settings.geminiApiKey;
    const fullPrompt = `Write a professional and catchy bio for a bio-link page (like Linktree). 
    Name: ${state.profile.name}. 
    Keywords/Role: ${prompt || state.profile.bio}. 
    Keep it under 150 characters. Return only the bio text.`;
    
    const result = await generateContent(apiKey, fullPrompt);
    if (result) {
      dispatch({ type: 'UPDATE_PROFILE', payload: { bio: result.trim() } });
    }
  };

  return (
    <div className="mt-2 space-y-2">
      {loading && <BioSkeleton />}
      <div className="flex gap-2">
        <input 
          placeholder="Enter keywords for AI bio..."
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          className="flex-1 text-xs p-2 border dark:border-slate-700 dark:bg-slate-900 rounded-lg"
        />
        <Button 
          size="sm" 
          onClick={handleGenerate} 
          disabled={loading}
          className="gap-2 text-xs"
        >
          {loading ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
          AI Rewrite
        </Button>
      </div>
    </div>
  );
}
