import React from 'react';
import { useBioStore } from '../../hooks/useBioStore.jsx';
import { useGemini } from '../../hooks/useGemini';
import { Button } from '../Shared/Button';
import { Sparkles, Loader2, Wand2 } from 'lucide-react';
import { Modal } from '../Shared/Modal';
import { TEMPLATES } from '../../utils/templates.config';
import { Skeleton } from '../Shared/Skeleton';

export function AITemplateRecommender() {
  const { state, dispatch } = useBioStore();
  const { generateContent, loading } = useGemini();
  const [isOpen, setIsOpen] = React.useState(false);
  const [recommendation, setRecommendation] = React.useState(null);
  const [vibe, setVibe] = React.useState('');

  const handleRecommend = async () => {
    const apiKey = state.settings.geminiApiKey;
    const prompt = `User describes their vibe/industry as: "${vibe || 'professional'}". 
    Their bio is: "${state.profile.bio}".
    Available templates: ${TEMPLATES.map(t => `${t.id} (${t.description})`).join(', ')}.
    Recommend the best template ID and a hex accent color.
    Return only JSON: {"templateId": "...", "accentColor": "#...", "reason": "..."}`;
    
    const result = await generateContent(apiKey, prompt);
    if (result) {
      try {
        const jsonStr = result.replace(/```json|```/g, '').trim();
        setRecommendation(JSON.parse(jsonStr));
      } catch (e) {
        console.error("Failed to parse recommendation", e);
      }
    }
  };

  const applyRecommendation = () => {
    if (recommendation) {
      dispatch({ type: 'SET_TEMPLATE', payload: recommendation.templateId });
      dispatch({ type: 'UPDATE_PROFILE', payload: { accentColor: recommendation.accentColor } });
      setIsOpen(false);
    }
  };

  return (
    <>
      <Button variant="ghost" size="sm" onClick={() => setIsOpen(true)} className="gap-2 text-blue-600">
        <Wand2 size={16} /> AI Recommend
      </Button>

      <Modal 
        isOpen={isOpen} 
        onClose={() => setIsOpen(false)} 
        title="AI Design Assistant"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Describe your vibe or industry</label>
            <input 
              placeholder="e.g. Cyberpunk, Minimalist Architect, Y2K Fashion..."
              value={vibe}
              onChange={(e) => setVibe(e.target.value)}
              className="w-full p-2 border dark:border-slate-700 dark:bg-slate-900 rounded-lg"
            />
          </div>
          
          <Button onClick={handleRecommend} disabled={loading} className="w-full gap-2">
            {loading ? <Loader2 size={18} className="animate-spin" /> : <Sparkles size={18} />}
            Get Recommendation
          </Button>

          {loading && (
            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-xl space-y-3">
              <Skeleton className="h-6 w-1/2" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <div className="flex items-center gap-3">
                <Skeleton className="h-8 w-8 rounded-full" />
                <Skeleton className="h-4 w-20" />
              </div>
              <Skeleton className="h-10 w-full rounded-lg" />
            </div>
          )}

          {recommendation && !loading && (
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800">
              <h4 className="font-bold text-blue-900 dark:text-blue-100 mb-1 capitalize">
                Recommended: {recommendation.templateId}
              </h4>
              <p className="text-sm text-blue-800 dark:text-blue-200 mb-4">{recommendation.reason}</p>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-full shadow-sm border border-white" style={{ backgroundColor: recommendation.accentColor }}></div>
                <span className="text-sm font-mono">{recommendation.accentColor}</span>
              </div>
              <Button onClick={applyRecommendation} className="w-full">Apply Design</Button>
            </div>
          )}
        </div>
      </Modal>
    </>
  );
}
