import React from 'react';
import { useBioStore } from '../../hooks/useBioStore.jsx';
import { useGemini } from '../../hooks/useGemini';
import { Button } from '../Shared/Button';
import { Sparkles, Loader2, Plus } from 'lucide-react';
import { Modal } from '../Shared/Modal';
import { LinkSkeleton } from '../Shared/Skeleton';

export function AILinkSuggester() {
  const { state, dispatch } = useBioStore();
  const { generateContent, loading } = useGemini();
  const [isOpen, setIsOpen] = React.useState(false);
  const [suggestions, setSuggestions] = React.useState([]);

  const handleSuggest = async () => {
    setIsOpen(true);
    const apiKey = state.settings.geminiApiKey;
    const prompt = `Based on this person's bio: "${state.profile.bio}" and name: "${state.profile.name}", suggest 3-5 relevant social media or platform links they should add. 
    Return a JSON array of objects with "label" and "icon" (must be a valid Lucide React icon name like Instagram, Twitter, Github, Youtube, Linkedin, Globe, Mail). 
    Format: [{"label": "Portfolio", "icon": "Globe"}]`;
    
    const result = await generateContent(apiKey, prompt);
    if (result) {
      try {
        // Clean markdown if present
        const jsonStr = result.replace(/```json|```/g, '').trim();
        setSuggestions(JSON.parse(jsonStr));
      } catch (e) {
        console.error("Failed to parse AI suggestions", e);
      }
    }
  };

  const addSuggestion = (sug) => {
    dispatch({ 
      type: 'ADD_LINK', 
      payload: { id: Date.now().toString(), label: sug.label, icon: sug.icon, url: 'https://' } 
    });
  };

  return (
    <>
      <Button variant="outline" size="sm" onClick={handleSuggest} disabled={loading} className="gap-2">
        {loading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
        AI Suggestions
      </Button>

      <Modal 
        isOpen={isOpen} 
        onClose={() => setIsOpen(false)} 
        title="AI Link Suggestions"
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-500">Based on your profile, here are some links you might want to add:</p>
          {loading ? (
            <LinkSkeleton />
          ) : (
            <div className="grid gap-3">
              {suggestions.map((sug, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-white dark:bg-slate-800 rounded-lg shadow-sm">
                      <Sparkles size={16} className="text-blue-500" />
                    </div>
                    <span className="font-medium">{sug.label}</span>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => addSuggestion(sug)} className="text-blue-600">
                    <Plus size={16} /> Add
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </Modal>
    </>
  );
}
