import React from 'react';
import { clsx } from 'clsx';
import * as Icons from 'lucide-react';

export function NeonDarkTemplate({ profile, links }) {
  const accentColor = profile.accentColor || '#00f3ff';
  
  return (
    <div className="min-h-full flex flex-col items-center py-12 px-6 bg-[#0a0a0c] text-white font-mono">
      <div className="w-full max-w-md flex flex-col items-center">
        {profile.avatar && (
          <img 
            src={profile.avatar} 
            alt={profile.name} 
            className="w-24 h-24 rounded-full object-cover mb-4 border-2 shadow-[0_0_15px_rgba(255,255,255,0.2)]"
            style={{ borderColor: accentColor }}
          />
        )}
        <h1 className="text-2xl font-bold mb-2 text-white" style={{ textShadow: `0 0 10px ${accentColor}` }}>{profile.name}</h1>
        <p className="text-slate-400 text-center mb-8 max-w-xs">{profile.bio}</p>

        <div className="w-full space-y-4">
          {links.map((link) => {
            const Icon = Icons[link.icon] || Icons.Link;
            return (
              <a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className={clsx(
                  "flex items-center justify-center gap-3 w-full p-4 border-2 transition-all hover:scale-[1.02] active:scale-[0.98]",
                  profile.buttonStyle === 'rounded-xl' ? 'rounded-xl' : 
                  profile.buttonStyle === 'rounded-full' ? 'rounded-full' : 'rounded-none'
                )}
                style={{ 
                  borderColor: accentColor, 
                  backgroundColor: 'rgba(0, 0, 0, 0.5)',
                  boxShadow: `0 0 10px ${accentColor}40`,
                  color: 'white'
                }}
              >
                <Icon size={20} style={{ color: accentColor }} />
                <span className="font-bold tracking-wider">{link.label}</span>
              </a>
            );
          })}
        </div>
      </div>
    </div>
  );
}
