import React from 'react';
import { clsx } from 'clsx';
import * as Icons from 'lucide-react';

export function GlassTemplate({ profile, links }) {
  return (
    <div className="min-h-full flex flex-col items-center py-12 px-6 font-sans text-white" 
         style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
      <div className="w-full max-w-md flex flex-col items-center">
        {profile.avatar && (
          <img 
            src={profile.avatar} 
            alt={profile.name} 
            className="w-24 h-24 rounded-full object-cover mb-4 border-2 border-white/30 shadow-lg"
          />
        )}
        <h1 className="text-2xl font-bold mb-2 drop-shadow-md">{profile.name}</h1>
        <p className="text-white/80 text-center mb-8 max-w-xs">{profile.bio}</p>

        <div className="w-full space-y-4">
          {links.map((link) => {
            const Icon = Icons[link.icon] || Icons.Link;
            return (
              <a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className={clsx(
                  "flex items-center justify-center gap-3 w-full p-4 glass transition-all hover:bg-white/20",
                  profile.buttonStyle === 'rounded-xl' ? 'rounded-xl' : 
                  profile.buttonStyle === 'rounded-full' ? 'rounded-full' : 'rounded-none'
                )}
                style={{ color: 'white' }}
              >
                <Icon size={20} className="text-white/70" />
                <span className="font-medium">{link.label}</span>
              </a>
            );
          })}
        </div>
      </div>
    </div>
  );
}
