import React from 'react';
import { clsx } from 'clsx';
import * as Icons from 'lucide-react';

export function MinimalTemplate({ profile, links }) {
  return (
    <div className="min-h-full flex flex-col items-center py-12 px-6 bg-white text-slate-800 font-sans">
      <div className="w-full max-w-md flex flex-col items-center">
        {profile.avatar && (
          <img 
            src={profile.avatar} 
            alt={profile.name} 
            className="w-24 h-24 rounded-full object-cover mb-4 border-2 border-slate-100 shadow-sm"
          />
        )}
        <h1 className="text-2xl font-bold mb-2 tracking-tight">{profile.name}</h1>
        <p className="text-slate-500 text-center mb-8 max-w-xs">{profile.bio}</p>

        <div className="w-full space-y-4">
          {links.map((link) => {
            const Icon = Icons[link.icon] || Icons.Link;
            return (
              <a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className={clsx(
                  "flex items-center justify-center gap-3 w-full p-4 border transition-all hover:bg-slate-50",
                  profile.buttonStyle === 'rounded-xl' ? 'rounded-xl' : 
                  profile.buttonStyle === 'rounded-full' ? 'rounded-full' : 'rounded-none'
                )}
                style={{ borderColor: profile.accentColor + '40', color: profile.accentColor }}
              >
                <Icon size={20} />
                <span className="font-medium text-slate-800">{link.label}</span>
              </a>
            );
          })}
        </div>
      </div>
    </div>
  );
}
