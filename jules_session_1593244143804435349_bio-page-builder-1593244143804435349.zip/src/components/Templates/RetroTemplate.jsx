import React from 'react';
import { clsx } from 'clsx';
import * as Icons from 'lucide-react';

export function RetroTemplate({ profile, links }) {
  return (
    <div className="min-h-full flex flex-col items-center py-12 px-6 bg-[#fef3c7] text-[#451a03] font-serif border-8 border-[#d97706]/20">
      <div className="w-full max-w-md flex flex-col items-center">
        <div className="relative mb-6">
          {profile.avatar && (
            <img 
              src={profile.avatar} 
              alt={profile.name} 
              className="w-24 h-24 rounded-lg object-cover border-4 border-[#451a03] grayscale hover:grayscale-0 transition-all"
            />
          )}
          <div className="absolute -bottom-2 -right-2 w-full h-full border-4 border-[#451a03] -z-10 rounded-lg"></div>
        </div>
        
        <h1 className="text-3xl font-black mb-1 uppercase tracking-tighter border-b-4 border-[#451a03] pb-1">{profile.name}</h1>
        <p className="text-[#451a03]/80 text-center mb-10 max-w-xs font-medium italic mt-2">"{profile.bio}"</p>

        <div className="w-full space-y-6">
          {links.map((link) => {
            const Icon = Icons[link.icon] || Icons.Link;
            return (
              <a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className={clsx(
                  "relative flex items-center justify-center gap-3 w-full p-4 border-4 border-[#451a03] bg-white transition-all hover:-translate-y-1 hover:-translate-x-1 active:translate-x-0 active:translate-y-0",
                  profile.buttonStyle === 'rounded-xl' ? 'rounded-md' : 
                  profile.buttonStyle === 'rounded-full' ? 'rounded-full' : 'rounded-none'
                )}
              >
                <div className="absolute inset-0 bg-[#451a03] translate-x-1 translate-y-1 -z-10"></div>
                <Icon size={20} strokeWidth={3} />
                <span className="font-black uppercase">{link.label}</span>
              </a>
            );
          })}
        </div>
      </div>
    </div>
  );
}
