import React from 'react';
import { clsx } from 'clsx';
import * as Icons from 'lucide-react';

export function GradientTemplate({ profile, links }) {
  const accentColor = profile.accentColor || '#f43f5e';
  
  return (
    <div className="min-h-full flex flex-col items-center py-12 px-6 font-retro text-white overflow-hidden relative" 
         style={{ background: 'linear-gradient(45deg, #ee9ca7 0%, #ffdde1 100%)' }}>
      {/* Mesh background effect */}
      <div className="absolute top-0 left-0 w-full h-full opacity-30 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-purple-400 rounded-full blur-[100px] animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-400 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="w-full max-w-md flex flex-col items-center relative z-10">
        {profile.avatar && (
          <div className="p-1 rounded-full bg-white/20 backdrop-blur-sm mb-4">
            <img 
              src={profile.avatar} 
              alt={profile.name} 
              className="w-24 h-24 rounded-full object-cover border-2 border-white shadow-xl"
            />
          </div>
        )}
        <h1 className="text-3xl font-black mb-2 text-slate-800 drop-shadow-sm">{profile.name}</h1>
        <p className="text-slate-600 text-center mb-8 max-w-xs font-medium">{profile.bio}</p>

        <div className="w-full space-y-4">
          {links.map((link) => {
            const Icon = Icons[link.icon] || Icons.Link;
            return (
              <a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className={clsx(
                  "flex items-center justify-between gap-3 w-full p-4 shadow-lg transition-all hover:scale-[1.03] active:scale-95 group",
                  profile.buttonStyle === 'rounded-xl' ? 'rounded-2xl' : 
                  profile.buttonStyle === 'rounded-full' ? 'rounded-full' : 'rounded-none'
                )}
                style={{ backgroundColor: accentColor }}
              >
                <div className="bg-white/20 p-2 rounded-lg group-hover:bg-white/30 transition-colors">
                  <Icon size={20} />
                </div>
                <span className="font-bold flex-1 text-center pr-8">{link.label}</span>
              </a>
            );
          })}
        </div>
      </div>
    </div>
  );
}
