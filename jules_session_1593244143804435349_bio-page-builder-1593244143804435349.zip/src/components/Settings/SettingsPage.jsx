import React from 'react';
import { useBioStore } from '../../hooks/useBioStore.jsx';
import { Button } from '../Shared/Button';
import { Key, Save, Trash2, Download, Upload, ShieldCheck } from 'lucide-react';
import { useToast } from '../Shared/Toast';

export function SettingsPage() {
  const { state, dispatch } = useBioStore();
  const { addToast } = useToast();

  const handleUpdateApiKey = (e) => {
    dispatch({ type: 'UPDATE_SETTINGS', payload: { geminiApiKey: e.target.value } });
  };

  const handleExportBackup = () => {
    const data = JSON.stringify(state);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bio-builder-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    addToast('Backup exported!', 'success');
  };

  const handleImportBackup = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target.result);
        dispatch({ type: 'HYDRATE', payload: imported });
        addToast('Backup imported successfully!', 'success');
      } catch (err) {
        addToast('Invalid backup file.', 'error');
      }
    };
    reader.readAsText(file);
  };

  const handleClearHistory = () => {
    if (confirm('Clear all saved snapshots? This cannot be undone.')) {
      dispatch({ type: 'HYDRATE', payload: { history: [] } });
      addToast('History cleared.', 'info');
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Settings</h2>

      <section className="bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg text-blue-600">
            <Key size={20} />
          </div>
          <div>
            <h3 className="font-bold">Gemini AI Integration</h3>
            <p className="text-xs text-slate-500">Required for AI features. Your key is stored locally.</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">API Key</label>
            <input
              type="password"
              value={state.settings.geminiApiKey}
              onChange={handleUpdateApiKey}
              className="w-full p-3 border dark:border-slate-700 dark:bg-slate-900 rounded-xl"
              placeholder="Enter your Gemini API Key..."
            />
          </div>
          <div className="flex items-center gap-2 text-xs text-green-600 bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
            <ShieldCheck size={14} />
            Your API key is never sent to our servers. It stays in your browser's localStorage.
          </div>
        </div>
      </section>

      <section className="bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700">
        <h3 className="font-bold mb-4">Data Management</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Button variant="outline" className="gap-2 justify-start" onClick={handleExportBackup}>
            <Download size={18} /> Export Backup
          </Button>
          <label className="flex items-center justify-center gap-2 px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
            <Upload size={18} /> Import Backup
            <input type="file" className="hidden" onChange={handleImportBackup} accept=".json" />
          </label>
          <Button variant="danger" className="gap-2 justify-start" onClick={handleClearHistory}>
            <Trash2 size={18} /> Clear All History
          </Button>
        </div>
      </section>

      <section className="bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700">
        <h3 className="font-bold mb-4">Preferences</h3>
        <div className="flex items-center justify-between">
          <span className="text-sm">Auto-save every 30s</span>
          <button 
            onClick={() => dispatch({ type: 'UPDATE_SETTINGS', payload: { autoSave: !state.settings.autoSave } })}
            className={`w-12 h-6 rounded-full transition-colors relative ${state.settings.autoSave ? 'bg-blue-600' : 'bg-slate-300 dark:bg-slate-600'}`}
          >
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${state.settings.autoSave ? 'left-7' : 'left-1'}`}></div>
          </button>
        </div>
      </section>
    </div>
  );
}
