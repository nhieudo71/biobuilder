import React from 'react';
import { useBioStore } from '../../hooks/useBioStore.jsx';
import { HistoryCard } from './HistoryCard';
import { Button } from '../Shared/Button';
import { Plus, History as HistoryIcon } from 'lucide-react';

export function HistoryPanel() {
  const { state, dispatch } = useBioStore();

  const handleSaveSnapshot = () => {
    const name = prompt('Enter a name for this snapshot:', `My Page ${new Date().toLocaleDateString()}`);
    if (name) {
      dispatch({ type: 'SAVE_SNAPSHOT', payload: { name } });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2 text-slate-800 dark:text-white">
          <HistoryIcon size={24} className="text-blue-500" />
          Saved Snapshots
        </h2>
        <Button onClick={handleSaveSnapshot} className="gap-2">
          <Plus size={18} /> Save Current
        </Button>
      </div>

      {state.history.length === 0 ? (
        <div className="text-center py-20 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-700">
          <HistoryIcon size={48} className="mx-auto text-slate-300 mb-4" />
          <p className="text-slate-500">No snapshots saved yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {state.history.map((snapshot) => (
            <HistoryCard key={snapshot.id} snapshot={snapshot} />
          ))}
        </div>
      )}
    </div>
  );
}
