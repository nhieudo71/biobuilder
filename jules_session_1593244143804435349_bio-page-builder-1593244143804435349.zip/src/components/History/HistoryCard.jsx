import React from 'react';
import { useBioStore } from '../../hooks/useBioStore.jsx';
import { Button } from '../Shared/Button';
import { Trash2, FolderOpen, Calendar, Layout } from 'lucide-react';
import { useToast } from '../Shared/Toast';

export function HistoryCard({ snapshot }) {
  const { dispatch } = useBioStore();
  const { addToast } = useToast();

  const handleLoad = () => {
    dispatch({ type: 'LOAD_SNAPSHOT', payload: snapshot.data });
    addToast('Snapshot loaded successfully!', 'success');
  };

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete this snapshot?')) {
      dispatch({ type: 'DELETE_SNAPSHOT', payload: snapshot.id });
      addToast('Snapshot deleted.', 'info');
    }
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl p-4 shadow-sm border border-slate-100 dark:border-slate-700 group transition-all hover:shadow-md">
      <div className="aspect-video bg-slate-100 dark:bg-slate-900 rounded-xl mb-4 flex items-center justify-center border border-slate-200 dark:border-slate-700 overflow-hidden relative">
        <div className="text-4xl opacity-50">{snapshot.data.templateId === 'minimal' ? '⚪' : snapshot.data.templateId === 'neon' ? '🌌' : '🫧'}</div>
        <div className="absolute top-2 right-2 px-2 py-1 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm rounded text-[10px] font-bold uppercase tracking-wider">
          {snapshot.data.templateId}
        </div>
      </div>
      
      <div className="mb-4">
        <h3 className="font-bold text-slate-800 dark:text-white truncate">{snapshot.name}</h3>
        <div className="flex items-center gap-1 text-xs text-slate-500 mt-1">
          <Calendar size={12} />
          {new Date(snapshot.date).toLocaleDateString()} at {new Date(snapshot.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>

      <div className="flex gap-2">
        <Button size="sm" variant="secondary" className="flex-1 gap-1.5" onClick={handleLoad}>
          <FolderOpen size={14} /> Load
        </Button>
        <Button 
          size="sm" 
          variant="ghost" 
          className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20" 
          onClick={handleDelete}
        >
          <Trash2 size={14} />
        </Button>
      </div>
    </div>
  );
}
