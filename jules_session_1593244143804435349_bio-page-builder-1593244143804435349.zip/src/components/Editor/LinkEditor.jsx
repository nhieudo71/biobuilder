import React, { useState } from 'react';
import { useBioStore } from '../../hooks/useBioStore.jsx';
import { Button } from '../Shared/Button';
import { Trash2, GripVertical, Plus, ExternalLink } from 'lucide-react';
import * as Icons from 'lucide-react';

export function LinkEditor() {
  const { state, dispatch } = useBioStore();
  const [newLink, setNewLink] = useState({ label: '', url: '', icon: 'Link' });

  const addLink = () => {
    if (!newLink.label || !newLink.url) return;
    dispatch({ 
      type: 'ADD_LINK', 
      payload: { ...newLink, id: Date.now().toString() } 
    });
    setNewLink({ label: '', url: '', icon: 'Link' });
  };

  const updateLink = (id, field, value) => {
    const link = state.links.find(l => l.id === id);
    dispatch({
      type: 'UPDATE_LINK',
      payload: { ...link, [field]: value }
    });
  };

  return (
    <div className="space-y-4">
      <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-slate-100 dark:border-slate-700">
        <div className="grid grid-cols-2 gap-3 mb-3">
          <input
            placeholder="Label (e.g. Instagram)"
            value={newLink.label}
            onChange={(e) => setNewLink({ ...newLink, label: e.target.value })}
            className="p-2 border dark:border-slate-700 dark:bg-slate-900 rounded-lg text-sm"
          />
          <input
            placeholder="URL (https://...)"
            value={newLink.url}
            onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
            className="p-2 border dark:border-slate-700 dark:bg-slate-900 rounded-lg text-sm"
          />
        </div>
        <div className="flex gap-2">
          <select 
            value={newLink.icon}
            onChange={(e) => setNewLink({ ...newLink, icon: e.target.value })}
            className="flex-1 p-2 border dark:border-slate-700 dark:bg-slate-900 rounded-lg text-sm"
          >
            {Object.keys(Icons).filter(name => typeof Icons[name] === 'function' && name.length < 20).slice(0, 50).map(iconName => (
              <option key={iconName} value={iconName}>{iconName}</option>
            ))}
          </select>
          <Button onClick={addLink} size="sm" className="gap-2">
            <Plus size={16} /> Add
          </Button>
        </div>
      </div>

      <div className="space-y-3">
        {state.links.map((link) => (
          <div key={link.id} className="bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-100 dark:border-slate-700 flex items-center gap-3">
            <div className="text-slate-400 cursor-grab">
              <GripVertical size={20} />
            </div>
            <div className="flex-1 grid grid-cols-2 gap-2">
              <input
                value={link.label}
                onChange={(e) => updateLink(link.id, 'label', e.target.value)}
                className="p-1.5 border-none focus:ring-1 focus:ring-blue-500 bg-slate-50 dark:bg-slate-900 rounded-md text-sm font-medium"
              />
              <input
                value={link.url}
                onChange={(e) => updateLink(link.id, 'url', e.target.value)}
                className="p-1.5 border-none focus:ring-1 focus:ring-blue-500 bg-slate-50 dark:bg-slate-900 rounded-md text-sm text-slate-500"
              />
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => dispatch({ type: 'DELETE_LINK', payload: link.id })}
              className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
            >
              <Trash2 size={18} />
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
