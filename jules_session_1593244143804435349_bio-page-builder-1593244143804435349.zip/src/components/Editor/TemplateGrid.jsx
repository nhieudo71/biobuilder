import React from 'react';
import { useBioStore } from '../../hooks/useBioStore.jsx';
import { TEMPLATES } from '../../utils/templates.config';
import { clsx } from 'clsx';

export function TemplateGrid() {
  const { state, dispatch } = useBioStore();

  return (
    <div>
      <label className="block text-sm font-medium mb-3 text-slate-700 dark:text-slate-300">Select Template</label>
      <div className="grid grid-cols-3 gap-3">
        {TEMPLATES.map((template) => (
          <button
            key={template.id}
            onClick={() => dispatch({ type: 'SET_TEMPLATE', payload: template.id })}
            className={clsx(
              "flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all",
              state.templateId === template.id
                ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20"
                : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-300"
            )}
          >
            <span className="text-3xl">{template.thumbnail}</span>
            <span className="text-xs font-semibold">{template.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
