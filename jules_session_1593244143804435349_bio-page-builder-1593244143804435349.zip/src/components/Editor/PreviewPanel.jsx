import React from 'react';
import { useBioStore } from '../../hooks/useBioStore.jsx';
import { MinimalTemplate } from '../Templates/MinimalTemplate';
import { NeonDarkTemplate } from '../Templates/NeonDarkTemplate';
import { GlassTemplate } from '../Templates/GlassTemplate';
import { RetroTemplate } from '../Templates/RetroTemplate';
import { GradientTemplate } from '../Templates/GradientTemplate';

export function PreviewPanel() {
  const { state } = useBioStore();
  const { profile, links, templateId } = state;

  const renderTemplate = () => {
    switch (templateId) {
      case 'neon':
        return <NeonDarkTemplate profile={profile} links={links} />;
      case 'glass':
        return <GlassTemplate profile={profile} links={links} />;
      case 'retro':
        return <RetroTemplate profile={profile} links={links} />;
      case 'gradient':
        return <GradientTemplate profile={profile} links={links} />;
      case 'minimal':
      default:
        return <MinimalTemplate profile={profile} links={links} />;
    }
  };

  return (
    <div className="relative w-full max-w-[375px] aspect-[9/19] bg-slate-900 rounded-[3rem] border-[8px] border-slate-800 shadow-2xl overflow-hidden">
      {/* Phone Notch */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-800 rounded-b-2xl z-20"></div>
      
      <div className="w-full h-full overflow-y-auto">
        {renderTemplate()}
      </div>
    </div>
  );
}
