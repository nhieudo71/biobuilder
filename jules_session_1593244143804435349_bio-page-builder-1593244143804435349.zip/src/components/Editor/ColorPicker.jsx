import React from 'react';
import { useBioStore } from '../../hooks/useBioStore.jsx';
import { FONT_PAIRS } from '../../utils/templates.config';
import { clsx } from 'clsx';

export function ColorPicker() {
  const { state, dispatch } = useBioStore();
  const { profile } = state;

  const buttonStyles = [
    { id: 'rounded-none', name: 'Square', class: 'rounded-none' },
    { id: 'rounded-xl', name: 'Rounded', class: 'rounded-xl' },
    { id: 'rounded-full', name: 'Pill', class: 'rounded-full' },
  ];

  const updateProfile = (updates) => {
    dispatch({ type: 'UPDATE_PROFILE', payload: updates });
  };

  return (
    <div className="space-y-6 bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm">
      <div>
        <label className="block text-sm font-medium mb-3 text-slate-700 dark:text-slate-300">Accent Color</label>
        <div className="flex items-center gap-4">
          <input
            type="color"
            value={profile.accentColor}
            onChange={(e) => updateProfile({ accentColor: e.target.value })}
            className="w-12 h-12 rounded-lg border-none cursor-pointer"
          />
          <input
            type="text"
            value={profile.accentColor}
            onChange={(e) => updateProfile({ accentColor: e.target.value })}
            className="flex-1 p-2 border dark:border-slate-700 dark:bg-slate-900 rounded-lg font-mono text-sm uppercase"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-3 text-slate-700 dark:text-slate-300">Font Pair</label>
        <div className="grid grid-cols-2 gap-2">
          {FONT_PAIRS.map((font) => (
            <button
              key={font.id}
              onClick={() => updateProfile({ fontFamily: font.id })}
              className={clsx(
                "p-3 rounded-lg border text-sm text-left transition-all",
                profile.fontFamily === font.id
                  ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400"
                  : "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700"
              )}
            >
              <div className="font-bold" style={{ fontFamily: font.main.replace(/"/g, '') }}>{font.name}</div>
              <div className="text-xs opacity-60">The quick brown fox...</div>
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-3 text-slate-700 dark:text-slate-300">Button Style</label>
        <div className="flex gap-2">
          {buttonStyles.map((style) => (
            <button
              key={style.id}
              onClick={() => updateProfile({ buttonStyle: style.id })}
              className={clsx(
                "flex-1 p-3 border text-sm transition-all",
                style.class,
                profile.buttonStyle === style.id
                  ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400"
                  : "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700"
              )}
            >
              {style.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
