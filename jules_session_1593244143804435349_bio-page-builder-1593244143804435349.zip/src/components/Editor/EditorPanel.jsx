import React from 'react';
import { useBioStore } from '../../hooks/useBioStore.jsx';
import { LinkEditor } from './LinkEditor';
import { TemplateGrid } from './TemplateGrid';
import { ColorPicker } from './ColorPicker';
import { AIBioWriter } from '../AI/AIBioWriter';
import { AILinkSuggester } from '../AI/AILinkSuggester';
import { AITemplateRecommender } from '../AI/AITemplateRecommender';

export function EditorPanel() {
  const { state, dispatch } = useBioStore();
  const { profile } = state;

  const handleChange = (e) => {
    const { name, value } = e.target;
    dispatch({ type: 'UPDATE_PROFILE', payload: { [name]: value } });
  };

  return (
    <div className="flex flex-col gap-8 pb-20">
      <section>
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
          <span className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600 text-sm">1</span>
          Profile Info
        </h2>
        <div className="grid gap-4 bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm">
          <div>
            <label className="block text-sm font-medium mb-1">Display Name</label>
            <input
              type="text"
              name="name"
              value={profile.name}
              onChange={handleChange}
              className="w-full p-2 border dark:border-slate-700 dark:bg-slate-900 rounded-lg"
              placeholder="Your Name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Bio</label>
            <textarea
              name="bio"
              value={profile.bio}
              onChange={handleChange}
              rows={3}
              className="w-full p-2 border dark:border-slate-700 dark:bg-slate-900 rounded-lg"
              placeholder="A short bio about yourself..."
            />
            <AIBioWriter />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Avatar URL</label>
            <input
              type="text"
              name="avatar"
              value={profile.avatar}
              onChange={handleChange}
              className="w-full p-2 border dark:border-slate-700 dark:bg-slate-900 rounded-lg"
              placeholder="https://example.com/avatar.png"
            />
          </div>
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <span className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600 text-sm">2</span>
            Social Links
          </h2>
          <AILinkSuggester />
        </div>
        <LinkEditor />
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <span className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600 text-sm">3</span>
            Design & Template
          </h2>
          <AITemplateRecommender />
        </div>
        <div className="space-y-6">
          <TemplateGrid />
          <ColorPicker />
        </div>
      </section>
    </div>
  );
}
