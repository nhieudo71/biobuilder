import React from 'react';

export function Skeleton({ className }) {
  return (
    <div className={`animate-pulse bg-slate-200 dark:bg-slate-700 rounded ${className}`}></div>
  );
}

export function BioSkeleton() {
  return (
    <div className="space-y-2 py-2">
      <Skeleton className="h-4 w-3/4" />
      <Skeleton className="h-4 w-1/2" />
    </div>
  );
}

export function LinkSkeleton() {
  return (
    <div className="grid gap-3 py-2">
      <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
        <div className="flex items-center gap-3">
          <Skeleton className="h-8 w-8 rounded-lg" />
          <Skeleton className="h-4 w-24" />
        </div>
        <Skeleton className="h-8 w-16 rounded-md" />
      </div>
      <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
        <div className="flex items-center gap-3">
          <Skeleton className="h-8 w-8 rounded-lg" />
          <Skeleton className="h-4 w-24" />
        </div>
        <Skeleton className="h-8 w-16 rounded-md" />
      </div>
    </div>
  );
}
