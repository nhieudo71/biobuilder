import React, { useEffect, useState } from 'react';
import { useBioStore } from './hooks/useBioStore.jsx';
import { useLocalStorage } from './hooks/useLocalStorage';
import { useAutoSave } from './hooks/useAutoSave';
import { EditorPanel } from './components/Editor/EditorPanel';
import { PreviewPanel } from './components/Editor/PreviewPanel';
import { HistoryPanel } from './components/History/HistoryPanel';
import { SettingsPage } from './components/Settings/SettingsPage';
import { Modal } from './components/Shared/Modal';
import { Button } from './components/Shared/Button';
import { decodeShareURL, encodeShareURL } from './utils/encodeShareURL';
import { exportToHTML } from './utils/exportHTML';
import { useToast } from './components/Shared/Toast';
import { 
  Layout, 
  History, 
  Settings, 
  Share2, 
  Download, 
  Moon, 
  Sun,
  ExternalLink,
  ChevronRight,
  Sparkles
} from 'lucide-react';

function App() {
  const { state, dispatch } = useBioStore();
  const [persistedState, setPersistedState] = useLocalStorage('bio-builder-state', null);
  const [activeTab, setActiveTab] = useState('editor');
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardingStep, setOnboardingStep] = useState(0);
  const { addToast } = useToast();

  // Hydrate from localStorage on mount
  useEffect(() => {
    if (persistedState) {
      dispatch({ type: 'HYDRATE', payload: persistedState });
    } else {
      setShowOnboarding(true);
    }
  }, []);

  // Sync state to localStorage
  useEffect(() => {
    setPersistedState(state);
  }, [state, setPersistedState]);

  // Handle Share URL on mount
  useEffect(() => {
    const sharedData = decodeShareURL(window.location.hash);
    if (sharedData) {
      if (confirm('Do you want to load the shared bio page? This will replace your current work.')) {
        dispatch({ type: 'LOAD_SNAPSHOT', payload: sharedData });
        addToast('Shared bio loaded!', 'success');
        window.location.hash = '';
      }
    }
  }, [dispatch, addToast]);

  // Enable Auto-save
  useAutoSave();

  // Handle Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        const name = prompt('Enter a name for this snapshot:', `My Page ${new Date().toLocaleDateString()}`);
        if (name) {
          dispatch({ type: 'SAVE_SNAPSHOT', payload: { name } });
          addToast('Snapshot saved!', 'success');
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [dispatch, addToast]);

  // Handle Dark Mode
  useEffect(() => {
    if (state.settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.settings.theme]);

  const toggleTheme = () => {
    dispatch({ 
      type: 'UPDATE_SETTINGS', 
      payload: { theme: state.settings.theme === 'light' ? 'dark' : 'light' } 
    });
  };

  const handleShare = () => {
    const url = encodeShareURL(state);
    navigator.clipboard.writeText(url);
    addToast('Share link copied to clipboard!', 'success');
  };

  const onboardingSteps = [
    { title: "Welcome to Bio Builder!", content: "Create a beautiful personal page for all your social links in minutes." },
    { title: "Design with AI", content: "Use our Gemini AI integration to write bios, suggest links, and recommend templates." },
    { title: "Share Everywhere", content: "Export as a standalone HTML file or share a live link with your followers." }
  ];

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 overflow-hidden">
      {/* Sidebar Navigation */}
      <aside className="w-20 md:w-64 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 flex flex-col">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-200 dark:shadow-none">
            <Layout size={24} />
          </div>
          <h1 className="text-xl font-black hidden md:block tracking-tight italic">BIO<span className="text-blue-600">BUILDER</span></h1>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          <NavItem 
            icon={<Layout size={20} />} 
            label="Editor" 
            active={activeTab === 'editor'} 
            onClick={() => setActiveTab('editor')} 
          />
          <NavItem 
            icon={<History size={20} />} 
            label="History" 
            active={activeTab === 'history'} 
            onClick={() => setActiveTab('history')} 
          />
          <NavItem 
            icon={<Settings size={20} />} 
            label="Settings" 
            active={activeTab === 'settings'} 
            onClick={() => setActiveTab('settings')} 
          />
        </nav>

        <div className="p-4 border-t border-slate-100 dark:border-slate-700 space-y-2">
          <Button variant="ghost" className="w-full justify-start gap-3 hidden md:flex" onClick={toggleTheme}>
            {state.settings.theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
            {state.settings.theme === 'light' ? 'Dark Mode' : 'Light Mode'}
          </Button>
          <div className="md:hidden flex justify-center">
             <Button variant="ghost" size="icon" onClick={toggleTheme}>
               {state.settings.theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
             </Button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-8 z-10">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-slate-500 capitalize">{activeTab}</span>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" className="gap-2" onClick={handleShare}>
              <Share2 size={16} /> <span className="hidden sm:inline">Share</span>
            </Button>
            <Button size="sm" className="gap-2" onClick={() => exportToHTML(state)}>
              <Download size={16} /> <span className="hidden sm:inline">Export HTML</span>
            </Button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8">
          {activeTab === 'editor' && (
            <div className="flex flex-col lg:flex-row gap-12 max-w-6xl mx-auto">
              <div className="flex-1 min-w-0">
                <EditorPanel />
              </div>
              <div className="lg:w-[400px] flex-shrink-0">
                <div className="sticky top-0 flex flex-col items-center">
                  <div className="mb-4 text-sm font-bold text-slate-400 uppercase tracking-widest">Live Preview</div>
                  <PreviewPanel />
                </div>
              </div>
            </div>
          )}
          {activeTab === 'history' && <HistoryPanel />}
          {activeTab === 'settings' && <SettingsPage />}
        </div>
      </main>

      {/* Onboarding Modal */}
      <Modal 
        isOpen={showOnboarding} 
        onClose={() => setShowOnboarding(false)}
        title={onboardingSteps[onboardingStep].title}
        footer={
          <div className="flex justify-between w-full items-center">
            <div className="flex gap-1">
              {onboardingSteps.map((_, i) => (
                <div key={i} className={`w-2 h-2 rounded-full transition-all ${i === onboardingStep ? 'w-4 bg-blue-600' : 'bg-slate-200'}`}></div>
              ))}
            </div>
            <Button onClick={() => {
              if (onboardingStep < onboardingSteps.length - 1) {
                setOnboardingStep(prev => prev + 1);
              } else {
                setShowOnboarding(false);
              }
            }} className="gap-2">
              {onboardingStep === onboardingSteps.length - 1 ? "Get Started" : "Next"} 
              <ChevronRight size={16} />
            </Button>
          </div>
        }
      >
        <div className="py-8 text-center">
          <div className="w-20 h-20 bg-blue-50 dark:bg-blue-900/30 rounded-3xl flex items-center justify-center text-blue-600 mx-auto mb-6">
            <Sparkles size={40} />
          </div>
          <p className="text-lg text-slate-600 dark:text-slate-400">
            {onboardingSteps[onboardingStep].content}
          </p>
        </div>
      </Modal>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
        active 
          ? "bg-blue-50 dark:bg-blue-900/20 text-blue-600 font-bold" 
          : "text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-700/50 hover:text-slate-900 dark:hover:text-white"
      }`}
    >
      {icon}
      <span className="hidden md:block">{label}</span>
    </button>
  );
}

export default App;
