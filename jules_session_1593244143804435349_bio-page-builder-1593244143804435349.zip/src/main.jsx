import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import { BioProvider } from './hooks/useBioStore.jsx'
import { ToastProvider } from './components/Shared/Toast'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ToastProvider>
      <BioProvider>
        <App />
      </BioProvider>
    </ToastProvider>
  </React.StrictMode>,
)
