export function exportToHTML(state) {
  const { profile, links, templateId } = state;
  const accentColor = profile.accentColor || '#3b82f6';
  const buttonRadius = profile.buttonStyle === 'rounded-xl' ? 'rounded-xl' : 
                       profile.buttonStyle === 'rounded-full' ? 'rounded-full' : 'rounded-none';

  let bodyStyles = '';
  let containerStyles = 'min-h-screen flex flex-col items-center py-12 px-6';
  let fontImport = '';
  let fontClass = 'font-sans';

  switch (templateId) {
    case 'neon':
      bodyStyles = 'background-color: #0a0a0c; color: white;';
      fontClass = 'font-mono';
      fontImport = '<link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;700&display=swap" rel="stylesheet">';
      break;
    case 'glass':
      bodyStyles = 'background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;';
      break;
    case 'retro':
      bodyStyles = 'background-color: #fef3c7; color: #451a03; border: 8px solid rgba(217, 119, 6, 0.2);';
      fontClass = 'font-serif';
      fontImport = '<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&display=swap" rel="stylesheet">';
      break;
    case 'gradient':
      bodyStyles = 'background: linear-gradient(45deg, #ee9ca7 0%, #ffdde1 100%); color: #1e293b;';
      fontClass = 'font-retro';
      fontImport = '<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;700&display=swap" rel="stylesheet">';
      break;
    default:
      bodyStyles = 'background-color: white; color: #1e293b;';
  }

  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${profile.name} | Bio</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
    ${fontImport}
    <script>
      tailwind.config = {
        theme: {
          extend: {
            fontFamily: {
              sans: ['Inter', 'sans-serif'],
              mono: ['"Fira Code"', 'monospace'],
              serif: ['"Playfair Display"', 'serif'],
              retro: ['"Space Grotesk"', 'sans-serif'],
            }
          }
        }
      }
    </script>
    <style>
      .glass { background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.2); }
      body { ${bodyStyles} }
    </style>
</head>
<body class="antialiased ${fontClass}">
    <div class="${containerStyles}">
      <div class="w-full max-w-md flex flex-col items-center text-center">
        ${profile.avatar ? `<img src="${profile.avatar}" class="w-24 h-24 rounded-full object-cover mb-4 border-2 shadow-sm" style="border-color: ${templateId === 'neon' ? accentColor : 'rgba(255,255,255,0.2)'}">` : ''}
        <h1 class="text-2xl font-bold mb-2 tracking-tight ${templateId === 'neon' ? 'text-white' : ''}" 
            style="${templateId === 'neon' ? `text-shadow: 0 0 10px ${accentColor}` : ''}">${profile.name}</h1>
        <p class="mb-8 max-w-xs ${templateId === 'minimal' ? 'text-slate-500' : 'opacity-80'}">${profile.bio}</p>
        <div class="w-full space-y-4">
          ${links.map(link => `
            <a href="${link.url}" target="_blank" class="flex items-center justify-center gap-3 w-full p-4 border transition-all ${buttonRadius} ${templateId === 'glass' ? 'glass' : ''}" 
               style="
                background-color: ${templateId === 'minimal' ? 'transparent' : templateId === 'neon' ? 'rgba(0,0,0,0.5)' : templateId === 'gradient' ? accentColor : 'white'};
                border-color: ${templateId === 'neon' ? accentColor : templateId === 'retro' ? '#451a03' : accentColor + '40'};
                color: ${templateId === 'gradient' || templateId === 'glass' || templateId === 'neon' ? 'white' : templateId === 'retro' ? '#451a03' : accentColor};
                ${templateId === 'neon' ? `box-shadow: 0 0 10px ${accentColor}40;` : ''}
                ${templateId === 'retro' ? 'border-width: 4px; position: relative;' : ''}
               ">
              <span class="font-bold uppercase tracking-wider">${link.label}</span>
            </a>
          `).join('')}
        </div>
      </div>
    </div>
</body>
</html>
  `;

  const blob = new Blob([html], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${profile.name.toLowerCase().replace(/\s+/g, '-')}-bio.html`;
  a.click();
  URL.revokeObjectURL(url);
}
