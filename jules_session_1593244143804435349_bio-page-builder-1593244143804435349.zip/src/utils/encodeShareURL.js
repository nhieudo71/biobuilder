export function encodeShareURL(state) {
  const data = {
    p: state.profile,
    l: state.links,
    t: state.templateId
  };
  const json = JSON.stringify(data);
  const base64 = btoa(encodeURIComponent(json));
  return `${window.location.origin}${window.location.pathname}#share=${base64}`;
}

export function decodeShareURL(hash) {
  if (!hash.startsWith('#share=')) return null;
  try {
    const base64 = hash.replace('#share=', '');
    const json = decodeURIComponent(atob(base64));
    const data = JSON.parse(json);
    return {
      profile: data.p,
      links: data.l,
      templateId: data.t
    };
  } catch (e) {
    console.error("Failed to decode share URL", e);
    return null;
  }
}
