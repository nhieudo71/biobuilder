export const TEMPLATES = [
  {
    id: 'minimal',
    name: 'Minimal',
    description: 'Clean white background, centered layout, thin typography',
    thumbnail: '⚪',
    defaultColors: { accent: '#3b82f6', background: '#ffffff', text: '#1e293b' },
    fonts: ['Inter', 'sans-serif'],
  },
  {
    id: 'neon',
    name: 'Neon Dark',
    description: 'Dark background, glowing neon colors, cyberpunk vibe',
    thumbnail: '🌌',
    defaultColors: { accent: '#00f3ff', background: '#0a0a0c', text: '#ffffff' },
    fonts: ['"Fira Code"', 'monospace'],
  },
  {
    id: 'glass',
    name: 'Glassmorphism',
    description: 'Frosted glass cards, gradient background, blur effects',
    thumbnail: '🫧',
    defaultColors: { accent: '#ffffff', background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', text: '#ffffff' },
    fonts: ['Inter', 'sans-serif'],
  },
  {
    id: 'retro',
    name: 'Retro',
    description: 'Vintage newspaper aesthetic, serif fonts, warm palette',
    thumbnail: '📜',
    defaultColors: { accent: '#c2410c', background: '#fef3c7', text: '#451a03' },
    fonts: ['"Playfair Display"', 'serif'],
  },
  {
    id: 'gradient',
    name: 'Gradient Flow',
    description: 'Bold gradient mesh background, colorful link buttons',
    thumbnail: '🌈',
    defaultColors: { accent: '#f43f5e', background: 'linear-gradient(45deg, #ee9ca7 0%, #ffdde1 100%)', text: '#ffffff' },
    fonts: ['"Space Grotesk"', 'sans-serif'],
  },
];

export const FONT_PAIRS = [
  { id: 'sans', name: 'Modern Sans', main: 'Inter', serif: false },
  { id: 'serif', name: 'Elegant Serif', main: '"Playfair Display"', serif: true },
  { id: 'mono', name: 'Cyber Mono', main: '"Fira Code"', serif: false },
  { id: 'retro', name: 'Retro Grotesk', main: '"Space Grotesk"', serif: false },
];
